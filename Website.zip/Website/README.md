# Vrinda Kalani Portfolio Website

A modern, interactive portfolio website built with Node.js, Express.js, and modern web technologies. This website features a minimalist design inspired by contemporary design portfolios with smooth animations and responsive layouts.

## Features

- **Modern Design**: Clean, minimalist layout with beautiful typography
- **Interactive Animations**: Smooth transitions, hover effects, and scroll animations
- **Responsive Design**: Fully responsive across all devices
- **Portfolio Showcase**: Dynamic portfolio grid with project details
- **Contact Form**: Interactive contact form with validation
- **Performance Optimized**: Fast loading times and smooth user experience

## Technologies Used

- **Backend**: Node.js, Express.js
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Templating**: EJS (Embedded JavaScript)
- **Styling**: Custom CSS with modern animations
- **Fonts**: Inter (sans-serif) and Playfair Display (serif)
- **Icons**: Font Awesome

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd vrinda-kalani-portfolio
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and visit `http://localhost:3000`

## Project Structure

```
vrinda-kalani-portfolio/
├── public/
│   ├── css/
│   │   └── style.css          # Main stylesheet
│   ├── js/
│   │   └── main.js            # Main JavaScript file
│   └── images/                # Image assets
├── views/
│   ├── layout.ejs             # Main layout template
│   ├── index.ejs              # Homepage
│   ├── about.ejs              # About page
│   └── contact.ejs            # Contact page
├── server.js                  # Express server
├── package.json               # Dependencies and scripts
└── README.md                  # This file
```

## Pages

- **Homepage** (`/`): Hero section, portfolio showcase, about preview
- **About** (`/about`): Detailed information about Vrinda Kalani
- **Contact** (`/contact`): Contact form and information

## Customization

### Adding New Projects
Edit the `projects` array in `server.js` to add new portfolio items:

```javascript
projects: [
    {
        id: 5,
        title: 'New Project',
        category: 'Category',
        image: '/images/new-project.jpg',
        description: 'Project description'
    }
]
```

### Styling
All styles are in `public/css/style.css`. The design uses CSS custom properties for easy theming:

```css
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --text-color: #333;
    --background-color: #ffffff;
}
```

### Animations
Animations are handled in `public/js/main.js` using:
- Intersection Observer API for scroll-triggered animations
- CSS transitions and transforms
- Custom JavaScript animations

## Performance Features

- Lazy loading for images
- Optimized CSS and JavaScript
- Responsive images
- Smooth scrolling
- Efficient animations using CSS transforms

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## Deployment

The website can be deployed to any Node.js hosting service:

1. **Heroku**: Connect your GitHub repository
2. **Vercel**: Deploy with zero configuration
3. **DigitalOcean**: Use App Platform
4. **AWS**: Use Elastic Beanstalk

## License

MIT License - feel free to use this template for your own portfolio.

## Contact

For questions or support, please contact Vrinda Kalani at hello@vrindakalani.com
