const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/portfolio', (req, res) => {
    res.render('layout', {
        title: 'Vrinda Kalani - Portfolio',
        page: 'index',
        projects: [
            {
                id: 1,
                title: 'Digital Art Collection',
                category: 'Digital Art',
                image: '/images/project1.jpg',
                description: 'A collection of contemporary digital artworks exploring themes of identity and technology.'
            },
            {
                id: 2,
                title: 'Brand Identity Design',
                category: 'Branding',
                image: '/images/project2.jpg',
                description: 'Complete brand identity design for a modern tech startup.'
            },
            {
                id: 3,
                title: 'Interactive Installation',
                category: 'Installation',
                image: '/images/project3.jpg',
                description: 'An immersive interactive art installation combining digital and physical elements.'
            },
            {
                id: 4,
                title: 'Web Design Portfolio',
                category: 'Web Design',
                image: '/images/project4.jpg',
                description: 'Modern, responsive web design for creative professionals.'
            }
        ]
    });
});

app.get('/about', (req, res) => {
    res.render('layout', {
        title: 'About - Vrinda Kalani',
        page: 'about'
    });
});

app.get('/contact', (req, res) => {
    res.render('layout', {
        title: 'Contact - Vrinda Kalani',
        page: 'contact'
    });
});

app.get('/lamp-scene', (req, res) => {
    res.sendFile(path.join(__dirname, 'lamp-scene.html'));
});

app.get('/lamp-scene-css', (req, res) => {
    res.sendFile(path.join(__dirname, 'lamp-scene-css.html'));
});

app.get('/lamp-simple', (req, res) => {
    res.sendFile(path.join(__dirname, 'lamp-simple.html'));
});

app.get('/bloom-lamp', (req, res) => {
    res.sendFile(path.join(__dirname, 'bloom-lamp-viewer.html'));
});

app.get('/bloom-lamp-interior', (req, res) => {
    res.sendFile(path.join(__dirname, 'bloom-lamp-interior.html'));
});

// Serve the OBJ file
app.get('/bloom-lamp.obj', (req, res) => {
    res.sendFile(path.join(__dirname, 'bloom lamp.obj'));
});

app.post('/contact', (req, res) => {
    const { name, email, message } = req.body;
    
    // Here you would typically send an email or save to database
    console.log('Contact form submission:', { name, email, message });
    
    res.json({ success: true, message: 'Thank you for your message!' });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
